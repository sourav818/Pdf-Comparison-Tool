import os
import hashlib
import PyPDF2
import pdfplumber
import difflib
import time

def compute_hash(file_path):
    hash_func = hashlib.md5()
    with open(file_path, 'rb') as f:
        while chunk := f.read(4096):
            hash_func.update(chunk)
    return hash_func.hexdigest()

def compare_binary(file1, file2):
    return compute_hash(file1) == compute_hash(file2)

def extract_text(file_path):
    text = ""
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text() or ""
    return text.strip()


def compare_text(file1, file2):
    text1 = extract_text(file1)
    text2 = extract_text(file2)
    return text1, text2, text1 == text2

def generate_highlighted_text_differences(text1, text2):
    diff = difflib.unified_diff(
        text1.splitlines(), text2.splitlines(),
        lineterm="", fromfile="File1", tofile="File2"
    )
    highlighted_diff = []
    for line in diff:
        if line.startswith('-'):
            highlighted_diff.append(f"\033[91m{line}\033[0m")  # Red for removed text
        elif line.startswith('+'):
            highlighted_diff.append(f"\033[92m{line}\033[0m")  # Green for added text
        else:
            highlighted_diff.append(line)
    return "\n".join(highlighted_diff)

def compare_metadata(file1, file2):
    reader1 = PyPDF2.PdfReader(file1)
    reader2 = PyPDF2.PdfReader(file2)
    return reader1.metadata, reader2.metadata, reader1.metadata == reader2.metadata

def generate_summary_report(report_path, diff_path):
    with open(report_path, "r", encoding="utf-8") as report_file:
        lines = report_file.readlines()
        total_comparisons = sum(1 for line in lines if line.startswith("Comparing"))
        identical_count = sum(1 for line in lines if "Identical" in line)
        diff_count = sum(1 for line in lines if "Different" in line)
    
    summary_report = f"""
    Summary of PDF Comparisons:
    ===========================
    Total Comparisons: {total_comparisons}
    Identical: {identical_count}
    Different: {diff_count}
    """
    
    with open(os.path.join(os.path.dirname(report_path), "summary_report.txt"), "w", encoding="utf-8") as summary_file:
        summary_file.write(summary_report)

def compare_all_pdfs(doc_folder, result_folder):
  
    start_time = time.time()

    pdf_files = [f for f in os.listdir(doc_folder) if f.endswith('.pdf')]
    if len(pdf_files) < 2:
        print("Need at least two PDF files for comparison.")
        return

    os.makedirs(result_folder, exist_ok=True)
    report_path = os.path.join(result_folder, "comparison_report.txt")
    diff_path = os.path.join(result_folder, "text_differences.txt")

    with open(report_path, "w", encoding="utf-8") as report_file, open(diff_path, "w", encoding="utf-8") as diff_file:
        report_file.write("PDF Comparison Report\n")
        report_file.write("=====================\n\n")
        diff_file.write("Text Differences\n")
        diff_file.write("================\n\n")

    
        for i in range(len(pdf_files)):
            for j in range(i + 1, len(pdf_files)):
                file1 = os.path.join(doc_folder, pdf_files[i])
                file2 = os.path.join(doc_folder, pdf_files[j])
                report_file.write(f"Comparing: {pdf_files[i]} and {pdf_files[j]}\n")

                # Binary Comparison
                binary_match = compare_binary(file1, file2)
                report_file.write(f"  Binary Content Match: {'Identical' if binary_match else 'Different'}\n")

                # Text Comparison
                text1, text2, text_match = compare_text(file1, file2)
                report_file.write(f"  Text Content Match: {'Identical' if text_match else 'Different'}\n")
                if not text_match:
                    diff_file.write(f"\nText Differences: {pdf_files[i]} vs {pdf_files[j]}\n")
                    diff_file.write(generate_highlighted_text_differences(text1, text2))
                    diff_file.write("\n")

                # Metadata Comparison
                metadata1, metadata2, metadata_match = compare_metadata(file1, file2)
                report_file.write(f"  Metadata Match: {'Identical' if metadata_match else 'Different'}\n")
                if not metadata_match:
                    report_file.write(f"    {pdf_files[i]} Metadata: {metadata1}\n")
                    report_file.write(f"    {pdf_files[j]} Metadata: {metadata2}\n")

                report_file.write("\n")

    # Track the time taken
    end_time = time.time()
    print(f"Comparison report saved at: {report_path}")
    print(f"Text differences saved at: {diff_path}")
    print(f"Time taken for comparison: {end_time - start_time:.2f} seconds")

    # Generate summary report
    generate_summary_report(report_path, diff_path)
    print("Summary report saved.")
    
if __name__ == "__main__":
    documents_folder = "documents"
    results_folder = "results"
    compare_all_pdfs(documents_folder, results_folder)
